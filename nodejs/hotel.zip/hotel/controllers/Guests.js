'use strict';

var utils = require('../utils/writer.js');
var Guests = require('../service/GuestsService');

module.exports.createGuest = function createGuest (req, res, next, body) {
  Guests.createGuest(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.guestsGET = function guestsGET (req, res, next) {
  Guests.guestsGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.guestsIdDELETE = function guestsIdDELETE (req, res, next, id) {
  Guests.guestsIdDELETE(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.guestsIdGET = function guestsIdGET (req, res, next, id) {
  Guests.guestsIdGET(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.guestsIdPUT = function guestsIdPUT (req, res, next, body, id) {
  Guests.guestsIdPUT(body, id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
