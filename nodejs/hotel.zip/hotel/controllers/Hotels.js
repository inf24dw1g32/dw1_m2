'use strict';

var utils = require('../utils/writer.js');
var Hotels = require('../service/HotelsService');

module.exports.hotelsGET = function hotelsGET (req, res, next) {
  Hotels.hotelsGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.hotelsIdDELETE = function hotelsIdDELETE (req, res, next, id) {
  Hotels.hotelsIdDELETE(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.hotelsIdGET = function hotelsIdGET(req, res, next, id) {
  Hotels.hotelsIdGET(id)
    .then(function(response) {
      // Resposta bem-sucedida
      utils.writeJson(res, response);
    })
    .catch(function(error) {
      // Resposta com erro
      if (error.code === 404) {
        // Se o hotel não for encontrado
        res.status(404).json({ message: error.message });
      } else {
        // Erro genérico
        res.status(500).json({ message: 'Internal Server Error', error: error });
      }
    });
};

module.exports.hotelsIdPUT = function hotelsIdPUT (req, res, next, body, id) {
  Hotels.hotelsIdPUT(body, id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.hotelsPOST = function hotelsPOST (req, res, next, body) {
  Hotels.hotelsPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
