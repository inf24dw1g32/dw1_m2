'use strict';

var utils = require('../utils/writer.js');
var Reservations = require('../service/ReservationsService');

module.exports.reservationsGET = function reservationsGET (req, res, next) {
  Reservations.reservationsGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.reservationsIdDELETE = function reservationsIdDELETE (req, res, next, id) {
  Reservations.reservationsIdDELETE(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.reservationsIdGET = function reservationsIdGET (req, res, next, id) {
  Reservations.reservationsIdGET(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.reservationsIdPUT = function reservationsIdPUT (req, res, next, body, id) {
  Reservations.reservationsIdPUT(body, id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.reservationsPOST = function reservationsPOST (req, res, next, body) {
  Reservations.reservationsPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.reservationsReportGET = function reservationsReportGET (req, res, next, guest_id, hotel_id, room_type_id) {
  Reservations.reservationsReportGET(guest_id, hotel_id, room_type_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.searchReservations = function searchReservations (req, res, next, guest_id, hotel_id, room_type_id) {
  Reservations.searchReservations(guest_id, hotel_id, room_type_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
