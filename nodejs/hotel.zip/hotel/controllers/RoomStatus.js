'use strict';

var utils = require('../utils/writer.js');
var RoomStatus = require('../service/RoomStatusService');

module.exports.roomStatusGET = function roomStatusGET (req, res, next, hotel_id, date) {
  RoomStatus.roomStatusGET(hotel_id, date)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
