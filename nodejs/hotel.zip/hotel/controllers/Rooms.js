'use strict';

var utils = require('../utils/writer.js');
var Rooms = require('../service/RoomsService');

module.exports.roomsGET = function roomsGET (req, res, next) {
  Rooms.roomsGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.roomsIdDELETE = function roomsIdDELETE (req, res, next, id) {
  Rooms.roomsIdDELETE(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.roomsIdGET = function roomsIdGET (req, res, next, id) {
  Rooms.roomsIdGET(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.roomsIdPUT = function roomsIdPUT (req, res, next, body, id) {
  Rooms.roomsIdPUT(body, id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.roomsPOST = function roomsPOST (req, res, next, body) {
  Rooms.roomsPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
