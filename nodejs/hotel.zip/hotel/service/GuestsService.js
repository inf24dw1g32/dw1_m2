'use strict';

var db = require('../utils/db'); // Assume que a conexão com o DB está no db.js

/**
 * List all guests
 *
 * returns List
 **/
exports.guestsGET = function() {
  return new Promise(function(resolve, reject) {
    // Selecionar todos os convidados da tabela
    db.query(
      `SELECT id, name, id_card, phone, address, country FROM guest`, function (err, results) {
      if (err) {
        reject({
          code: err.code,
          message: err.sqlMessage,
        });
      } else {
        resolve(results);
      }
    });
  });
}

/**
 * Delete a guest
 *
 * id Integer 
 * no response value expected for this operation
 **/
exports.guestsIdDELETE = function(id) {
  return new Promise(function(resolve, reject) {
    // Deletar um convidado pela ID
    db.query('DELETE FROM guest WHERE id = ?', [id], function(err, results) {
      if (err) {
        reject({
          code: err.code,
          message: err.sqlMessage,
        });
      } else {
        resolve({ message: 'Guest deleted successfully.' });
      }
    });
  });
}

/**
 * Get details of a specific guest
 *
 * id Integer 
 * returns Guest
 **/
exports.guestsIdGET = function(id) {
  return new Promise(function(resolve, reject) {
    // Obter detalhes de um convidado pela ID
    db.query('SELECT id, name, id_card, phone, address, country FROM guest WHERE id = ?', [id], function(err, results) {
      if (err) {
        reject({
          code: err.code,
          message: err.sqlMessage,
        });
      } else if (results.length === 0) {
        reject({ message: 'Guest not found.' });
      } else {
        resolve(results[0]);  // Retorna o primeiro resultado (único)
      }
    });
  });
}

/**
 * Update data of a specific guest
 *
 * body Guest 
 * id Integer 
 * no response value expected for this operation
 **/
exports.guestsIdPUT = function(body, id) {
  return new Promise(function(resolve, reject) {
    // Atualizar os dados do convidado pela ID
    const { name, country, address, phone, id_card } = body;
    db.query(
      `UPDATE guest SET name = ?, id_card = ?, phone = ?, address = ?, country = ? WHERE id = ?`,
      [body.name, body.id_card, body.phone, body.address, body.country, id],
      function (err, results) {
        if (err) {
          reject({
            code: err.code,
            message: err.sqlMessage,
          });
        } else {
          resolve({ message: 'Guest updated successfully.' });
        }
    });
  });
}

/**
 * Create a new guest
 *
 * body Guest 
 * no response value expected for this operation
 **/
exports.guestsPOST = function(body) {
  return new Promise(function(resolve, reject) {
    // Inserir um novo convidado
    const { name, country, address, phone, id_card } = body;
    db.query(`INSERT INTO guest (id, name, id_card, phone, address, country) VALUES (?, ?, ?, ?, ?, ?)`, 
      [name, country, address, phone, id_card], function(err, results) {
        if (err) {
          reject({
            code: err.code,
            message: err.sqlMessage,
          });
        } else {
          resolve({ message: 'Guest created successfully.', guestId: results.insertId });
        }
    });
  });
}

