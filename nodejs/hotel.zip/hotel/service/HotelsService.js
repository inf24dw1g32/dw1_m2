'use strict';

// Importando o db.js da pasta utils
const db = require('../utils/db'); // Caminho atualizado

// Listar todos os hotéis
exports.hotelsGET = function() {
  return new Promise(function(resolve, reject) {
    db.promise().query('SELECT id, name, stars, address, city, country FROM hotel')
      .then(([rows]) => {
        // Aqui você pode manipular os dados retornados da consulta
        console.log(rows);  // Para depurar e ver os dados
        resolve(rows);  // Retorna os dados
      })
      .catch(err => {
        console.error('Erro na consulta: ', err);
        reject(err);  // Retorna o erro
      });
  });
};

// Obter detalhes de um hotel específico
exports.hotelsIdGET = async function (id) {
  try {
    // Executa a consulta ao banco usando o pool
    const [rows] = await db.promise().query('SELECT id, name, stars, address, city, country FROM hotel WHERE id = ?', [id]);
    if (rows.length === 0) {
      throw new Error('Hotel não encontrado');
    }
    const hotel = rows[0];
    return {
      id: hotel.id,
      name: hotel.name,
      stars: hotel.stars,
      address: hotel.address,
      city: hotel.city,
      country: hotel.country
    };
  } catch (error) {
    throw new Error('Erro ao buscar hotel: ' + error.message);
  }
};

// Deletar um hotel
exports.hotelsIdDELETE = async function (id) {
  try {
    // Executa a consulta de exclusão ao banco usando o pool
    await db.promise().query('DELETE FROM hotel WHERE id = ?', [id]);
    return { message: 'Hotel excluído com sucesso' };
  } catch (error) {
    throw new Error('Erro ao excluir hotel: ' + error.message);
  }
};

// Criar um novo hotel
exports.hotelsPOST = async function (body) {
  try {
    const { name, stars, address, city, country } = body;
    const result = await db.promise().query(
      'INSERT INTO hotel (name, stars, address, city, country) VALUES (?, ?, ?, ?, ?)', 
      [name, stars, address, city, country]
    );
    return { id: result[0].insertId, message: 'Hotel criado com sucesso' };
  } catch (error) {
    throw new Error('Erro ao criar hotel: ' + error.message);
  }
};

// Atualizar um hotel específico
exports.hotelsIdPUT = async function (body, id) {
  try {
    const { name, stars, address, city, country } = body;
    // Executa a consulta de atualização ao banco usando o pool
    await db.promise().query(
      'UPDATE hotel SET name = ?, stars = ?, address = ?, city = ?, country = ? WHERE id = ?',
      [name, stars, address, city, country, id]
    );
    return { message: 'Hotel atualizado com sucesso' };
  } catch (error) {
    throw new Error('Erro ao atualizar hotel: ' + error.message);
  }
};

