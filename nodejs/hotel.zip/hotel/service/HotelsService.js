'use strict';


const db = require('../utils/db'); 

// Listar todos os hotéis
exports.hotelsGET = function() {
  return new Promise(function(resolve, reject) {
    db.promise().query('SELECT id, name, stars FROM hotel')
      .then(([rows]) => {
        // Aqui você pode manipular os dados retornados da consulta
        console.log(rows);  // Para depurar e ver os dados
        resolve(rows);  // Retorna os dados
      })
      .catch(err => {
        console.error('Erro na consulta: ', err);
        reject(err);  // Retorna o erro
      });
  });
};

// Obter detalhes de um hotel específico
exports.hotelsIdGET = function(id) {
  return new Promise(function(resolve, reject) {
    // Query para obter o hotel, restaurantes e serviços, garantindo que sejam únicos
    const query = `
      SELECT h.id AS hotel_id, h.name AS hotel_name, h.stars, h.address, h.city, h.country,
             r.id AS restaurant_id, r.name AS restaurant_name, r.category, r.meal_type,
             s.id AS service_id, s.name AS service_name
      FROM hotel h
      LEFT JOIN restaurant r ON r.hotel_id = h.id
      LEFT JOIN service s ON s.hotel_id = h.id
      WHERE h.id = ?
    `;

    db.query(query, [id], function(err, results) {
      if (err) {
        reject({ code: 500, message: 'Internal Server Error', error: err });
        return;
      }

      if (results.length === 0) {
        reject({ code: 404, message: 'Hotel not found' });
        return;
      }

      // Organize the results to match the response structure defined in OpenAPI
      const hotel = {
        id: results[0].hotel_id,
        name: results[0].hotel_name,
        stars: results[0].stars,
        address: results[0].address,
        city: results[0].city,
        country: results[0].country,
        restaurants: [],
        services: []
      };

      // Use Sets to ensure unique values for restaurants and services
      const restaurantSet = new Map();
      const serviceSet = new Map();

      results.forEach(row => {
        // Verifique se o restaurante é único
        if (row.restaurant_id && !restaurantSet.has(row.restaurant_id)) {
          restaurantSet.set(row.restaurant_id, {
            id: row.restaurant_id,
            name: row.restaurant_name,
            category: row.category,
            meal_type: row.meal_type
          });
        }

        // Verifique se o serviço é único
        if (row.service_id && !serviceSet.has(row.service_id)) {
          serviceSet.set(row.service_id, {
            id: row.service_id,
            name: row.service_name
          });
        }
      });

      // Converta os Set para Arrays e adicione ao hotel
      hotel.restaurants = Array.from(restaurantSet.values());
      hotel.services = Array.from(serviceSet.values());

      resolve(hotel);
    });
  });
};

// Deletar um hotel
exports.hotelsIdDELETE = async function (id) {
  try {
    // Executa a consulta de exclusão ao banco usando o pool
    await db.promise().query('DELETE FROM hotel WHERE id = ?', [id]);
    return { message: 'Hotel excluído com sucesso' };
  } catch (error) {
    throw new Error('Erro ao excluir hotel: ' + error.message);
  }
};

// Criar um novo hotel
exports.hotelsPOST = async function (body) {
  try {
    const { name, stars, address, city, country } = body;
    const result = await db.promise().query(
      'INSERT INTO hotel (name, stars, address, city, country) VALUES (?, ?, ?, ?, ?)', 
      [name, stars, address, city, country]
    );
    return { id: result[0].insertId, message: 'Hotel criado com sucesso' };
  } catch (error) {
    throw new Error('Erro ao criar hotel: ' + error.message);
  }
};

// Atualizar um hotel específico
exports.hotelsIdPUT = async function (body, id) {
  try {
    const { name, stars, address, city, country } = body;
    // Executa a consulta de atualização ao banco usando o pool
    await db.promise().query(
      'UPDATE hotel SET name = ?, stars = ?, address = ?, city = ?, country = ? WHERE id = ?',
      [name, stars, address, city, country, id]
    );
    return { message: 'Hotel atualizado com sucesso' };
  } catch (error) {
    throw new Error('Erro ao atualizar hotel: ' + error.message);
  }
};

