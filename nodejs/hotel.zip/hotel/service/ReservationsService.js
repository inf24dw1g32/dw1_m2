'use strict';

const db = require('../utils/db'); // Gerenciador de conexão ao banco de dados

/**
 * List all reservations (summary)
 * returns List
 **/
exports.reservationsGET = function () {
  return new Promise(function (resolve, reject) {
    const query = `
      SELECT id, guest_id, hotel_id
      FROM reservations;
    `;
    db.query(query, (error, results) => {
      if (error) {
        reject({ error: error.message });
      } else {
        resolve(results);
      }
    });
  });
};

/**
 * Delete a specific reservation
 * id Integer
 * no response value expected for this operation
 **/
exports.reservationsIdDELETE = function (id) {
  return new Promise(function (resolve, reject) {
    const query = `
      DELETE FROM reservations
      WHERE id = ?;
    `;
    db.query(query, [id], (error, results) => {
      if (error) {
        reject({ error: error.message });
      } else if (results.affectedRows === 0) {
        reject({ error: "Reservation not found" });
      } else {
        resolve({ message: "Reservation deleted successfully" });
      }
    });
  });
};

/**
 * Get details of a specific reservation
 * id Integer
 * returns Reservation
 **/
exports.reservationsIdGET = function (id) {
  return new Promise(function (resolve, reject) {
    const query = `
      SELECT *
      FROM reservations
      WHERE id = ?;
    `;
    db.query(query, [id], (error, results) => {
      if (error) {
        reject({ error: error.message });
      } else if (results.length === 0) {
        reject({ error: "Reservation not found" });
      } else {
        resolve(results[0]);
      }
    });
  });
};

/**
 * Update data of a specific reservation
 * body ReservationInput
 * id Integer
 * no response value expected for this operation
 **/
exports.reservationsIdPUT = function (body, id) {
  return new Promise(function (resolve, reject) {
    const query = `
      UPDATE reservations
      SET guest_id = ?, room_id = ?, check_in = ?, nights = ?, regime_id = ?, booking_method = ?,
          guest_count = ?, credit_card = ?, address = ?, contact_phone = ?, date = ?, guest_name = ?
      WHERE id = ?;
    `;
    const values = [
      body.guest_id,
      body.room_id,
      body.check_in,
      body.nights,
      body.regime_id,
      body.booking_method,
      body.guest_count,
      body.credit_card,
      body.address,
      body.contact_phone,
      body.date,
      body.guest_name,
      id,
    ];

    db.query(query, values, (error, results) => {
      if (error) {
        reject({ error: error.message });
      } else if (results.affectedRows === 0) {
        reject({ error: "Reservation not found" });
      } else {
        resolve({ message: "Reservation updated successfully" });
      }
    });
  });
};

/**
 * Create a new reservation
 * body ReservationInput
 * returns ReservationInput
 **/
exports.reservationsPOST = function (body) {
  return new Promise(function (resolve, reject) {
    const query = `
      INSERT INTO reservations
      (guest_id, room_id, check_in, nights, regime_id, booking_method, guest_count, credit_card,
       address, contact_phone, date, guest_name)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    `;
    const values = [
      body.guest_id,
      body.room_id,
      body.check_in,
      body.nights,
      body.regime_id,
      body.booking_method,
      body.guest_count,
      body.credit_card,
      body.address,
      body.contact_phone,
      body.date,
      body.guest_name,
    ];

    db.query(query, values, (error, results) => {
      if (error) {
        reject({ error: error.message });
      } else {
        resolve({
          id: results.insertId,
          message: "Reservation created successfully",
        });
      }
    });
  });
};

/**
 * Get reservations grouped by guest, hotel, and room type
 * guest_id Integer Filter by a specific guest ID (optional)
 * hotel_id Integer Filter by a specific hotel ID (optional)
 * room_type_id Integer Filter by a specific room type ID (optional)
 * returns List
 **/
exports.reservationsReportGET = function (guest_id, hotel_id, room_type_id) {
  return new Promise(function (resolve, reject) {
    let query = `
      SELECT g.name AS guest_name, h.name AS hotel_name, rt.name AS room_type,  -- Exibindo room_type.name
             COUNT(r.id) AS total_reservations
      FROM reservations r
      JOIN guest g ON r.guest_id = g.id
      JOIN room rm ON r.room_id = rm.id
      JOIN room_type rt ON rm.room_type_id = rt.id  -- Join para obter o nome do tipo de quarto
      JOIN hotel h ON rm.hotel_id = h.id
      WHERE 1=1
    `;
    const params = [];
    
    // Filtrando por guest_id, se fornecido
    if (guest_id) {
      query += " AND r.guest_id = ?";
      params.push(guest_id);
    }
    
    // Filtrando por hotel_id, se fornecido
    if (hotel_id) {
      query += " AND h.id = ?";
      params.push(hotel_id);
    }
    
    // Filtrando por room_type_id, se fornecido
    if (room_type_id) {
      query += " AND rt.id = ?";
      params.push(room_type_id);  // Usando room_type_id para filtrar
    }
    
    query += " GROUP BY guest_name, hotel_name, room_type;";  // Agrupando pelos campos desejados

    db.query(query, params, (error, results) => {
      if (error) {
        reject({ error: error.message });
      } else {
        resolve(results);  // Retornando os resultados com o nome do tipo de quarto
      }
    });
  });
};

