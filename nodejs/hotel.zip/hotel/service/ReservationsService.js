'use strict';

var db = require('../utils/db'); // A conexão com o banco de dados

/**
 * List all reservations
 *
 * returns List
 **/
exports.reservationsGET = function() {
  return new Promise(function(resolve, reject) {
    // Selecionar todas as reservas da tabela reservations
    db.query(`SELECT id, date, booking_method, guest_count, credit_card, guest_name, address, contact_phone, guest_id FROM reservation`, function(err, results) {
      if (err) {
        reject({
          code: err.code,
          message: err.sqlMessage,
        });
      } else {
        resolve(results);
      }
    });
  });
}

/**
 * Delete a reservation
 *
 * id Integer 
 * no response value expected for this operation
 **/
exports.reservationsIdDELETE = function(id) {
  return new Promise(function(resolve, reject) {
    // Deletar uma reserva pela ID
    db.query('DELETE FROM reservation WHERE id = ?', [id], function(err, results) {
      if (err) {
        reject({
          code: err.code,
          message: err.sqlMessage,
        });
      } else {
        resolve({ message: 'Reservation deleted successfully.' });
      }
    });
  });
}

/**
 * Get details of a specific reservation
 *
 * id Integer 
 * returns Reservation
 **/
exports.reservationsIdGET = function(id) {
  return new Promise(function(resolve, reject) {
    // Obter detalhes de uma reserva específica pela ID
    db.query(`SELECT id, date, booking_method, guest_count, credit_card, guest_name, address, contact_phone, guest_id FROM reservation WHERE id = ?`, [id], function(err, results) {
      if (err) {
        reject({
          code: err.code,
          message: err.sqlMessage,
        });
      } else if (results.length === 0) {
        reject({ message: 'Reservation not found.' });
      } else {
        resolve(results[0]); // Retorna o primeiro resultado (único)
      }
    });
  });
}

/**
 * Update data of a specific reservation
 *
 * body Reservation 
 * id Integer 
 * no response value expected for this operation
 **/
exports.reservationsIdPUT = function(body, id) {
  return new Promise(function(resolve, reject) {
    // Atualizar os dados da reserva específica
    const { date, credit_card, guest_id, guest_count, booking_method } = body;
    db.query(`UPDATE reservation SET date = ?, booking_method = ?, guest_count = ?, credit_card = ?, guest_name = ?, address = ?, contact_phone = ?, guest_id = ? WHERE id = ?`, 
      [date, credit_card, guest_id, guest_count, booking_method, id], function(err, results) {
        if (err) {
          reject({
            code: err.code,
            message: err.sqlMessage,
          });
        } else {
          resolve({ message: 'Reservation updated successfully.' });
        }
    });
  });
}

/**
 * Create a new reservation
 *
 * body Reservation 
 * no response value expected for this operation
 **/
exports.reservationsPOST = function(body) {
  return new Promise(function(resolve, reject) {
    // Inserir uma nova reserva
    const { date, credit_card, guest_id, guest_count, booking_method } = body;
    db.query(`INSERT INTO reservation (id, date, booking_method, guest_count, credit_card, guest_name, address, contact_phone, guest_id) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
      [date, credit_card, guest_id, guest_count, booking_method], function(err, results) {
        if (err) {
          reject({
            code: err.code,
            message: err.sqlMessage,
          });
        } else {
          resolve({ message: 'Reservation created successfully.', reservationId: results.insertId });
        }
    });
  });
}
