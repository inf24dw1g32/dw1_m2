'use strict';

var db = require('../utils/db'); // Importa a conexão com o banco de dados

/**
 * Get available rooms in a hotel for a specific date
 *
 * hotel_id Integer 
 * date date 
 * returns List
 **/
exports.roomStatusGET = function (hotel_id, date) {
  return new Promise(function (resolve, reject) {
    const query = `
      SELECT 
        r.id AS room_id,
        r.number AS room_number,
        r.price AS price_per_night,
        rt.name AS room_type,
        rt.capacity AS capacity
      FROM 
        room r
      INNER JOIN 
        room_type rt ON r.room_type_id = rt.id
      WHERE 
        r.hotel_id = ?
        AND r.id NOT IN (
          SELECT 
            rg.room_id
          FROM 
            reservation_guest rg
          WHERE 
            DATE_ADD(rg.check_in, INTERVAL rg.nights DAY) > ?
            AND rg.check_in <= ?
        )
    `;

    db.query(query, [hotel_id, date, date], function (err, results) {
      if (err) {
        reject({
          code: err.code,
          message: err.sqlMessage,
        });
      } else {
        resolve(results);
      }
    });
  });
};
