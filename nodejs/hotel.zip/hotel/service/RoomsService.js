'use strict';

var db = require('../utils/db'); // Conexão com o banco de dados

/**
 * List all rooms
 *
 * returns List
 **/
exports.roomsGET = function() {
  return new Promise(function(resolve, reject) {
    // Seleciona todas as informações das salas (rooms) na tabela 'rooms'
    db.query(`SELECT id, hotel_id, number FROM room`, function(err, results) {
      if (err) {
        reject({
          code: err.code,
          message: err.sqlMessage,
        });
      } else {
        resolve(results);
      }
    });
  });
}

/**
 * Delete a room
 *
 * id Integer 
 * no response value expected for this operation
 **/
exports.roomsIdDELETE = function(id) {
  return new Promise(function(resolve, reject) {
    // Deletar um quarto pela ID
    db.query('DELETE FROM room WHERE id = ?', [id], function(err, results) {
      if (err) {
        reject({
          code: err.code,
          message: err.sqlMessage,
        });
      } else {
        resolve({ message: 'Room deleted successfully.' });
      }
    });
  });
}

/**
 * Get details of a specific room
 *
 * id Integer 
 * returns Room
 **/
exports.roomsIdGET = function(id) {
  return new Promise(function(resolve, reject) {
    // Obter os detalhes de um quarto específico pela ID
    db.query(
      `SELECT id, hotel_id, room_type_id, number, price FROM room WHERE id = ?`,
      [id],
      function (err, results) {
      if (err) {
        reject({
          code: err.code,
          message: err.sqlMessage,
        });
      } else if (results.length === 0) {
        reject({ message: 'Room not found.' });
      } else {
        resolve(results[0]); // Retorna o primeiro resultado (único)
      }
    });
  });
}

/**
 * Update data of a specific room
 *
 * body Room 
 * id Integer 
 * no response value expected for this operation
 **/
exports.roomsIdPUT = function(body, id) {
  return new Promise(function(resolve, reject) {
    // Atualiza os dados de um quarto específico
    const { number, price, hotel_id, room_type_id } = body;
    db.query(`UPDATE room SET hotel_id = ?, room_type_id = ?, number = ?, price = ? WHERE id = ?`,
      [body.hotel_id, body.room_type_id, body.number, body.price, id],
      function (err, results) {
        if (err) {
          reject({
            code: err.code,
            message: err.sqlMessage,
          });
        } else {
          resolve({ message: 'Room updated successfully.' });
        }
    });
  });
}

/**
 * Create a new room
 *
 * body Room 
 * no response value expected for this operation
 **/
exports.roomsPOST = function(body) {
  return new Promise(function(resolve, reject) {
    // Insere um novo quarto na tabela 'rooms'
    const { number, price, hotel_id, room_type_id } = body;
    db.query(
      `INSERT INTO room (id, hotel_id, room_type_id, number, price) VALUES (?, ?, ?, ?, ?)`,
      [body.id, body.hotel_id, body.room_type_id, body.number, body.price], function(err, results) {
        if (err) {
          reject({
            code: err.code,
            message: err.sqlMessage,
          });
        } else {
          resolve({ message: 'Room created successfully.', roomId: results.insertId });
        }
    });
  });
}
