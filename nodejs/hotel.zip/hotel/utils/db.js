'use strict';

var mysql = require('mysql2');

var connection = mysql.createConnection({
    host: process.env.MYSQL_HOST || 'mysql',
    user: process.env.MYSQL_USER || 'root',
    password: process.env.MYSQL_PASSWORD || '12345678',
    database: process.env.MYSQL_DB || 'hotel',
    port: process.env.MYSQL_PORT || 3307
});

connection.connect(function (err) {
    if (err) {
        console.log('Error on database connection');
        throw err;
    }
    console.log('Database connection active.');
});

module.exports = connection; 